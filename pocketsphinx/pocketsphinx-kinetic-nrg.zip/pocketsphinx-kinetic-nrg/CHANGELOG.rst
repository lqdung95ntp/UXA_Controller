^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pocketsphinx
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2014-06-03)
------------------
* add ~source parameter, for setting things like 'alsasrc'
* add depend on python-gst
* Contributors: Michael Ferguson

0.3.0 (2013-11-27)
------------------
* Convert print statements to rosinfo/rosdebugs
* Change language model at runtime + specify audio source

0.2.2 (2013-09-29)
------------------
* Add changelog

0.2.1 (2013-09-21)
------------------
* Fix install rules so that python scripts are executable

0.2.0 (2013-07-12)
------------------
* Added support for grammar fsg files
* First catkinized release
